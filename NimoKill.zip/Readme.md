Readme


NimoKill.exe

This exe will destroy your computer
By Doge-509 ( adriancruz1498-cyber On Github )
Please create a virtual machino for run!
I am not responsible for damages caused by malware.